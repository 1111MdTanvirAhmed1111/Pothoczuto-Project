import React from 'react'
import { Outlet } from 'react-router-dom'
import Navbar from './components/Navbar';
import { useTheme } from './Api/ThemeContext';


function App() {
  const {theme} = useTheme()
  return (
    <div className={theme}>
      <Navbar />
    <Outlet />
    </div>
  )
}

export default App